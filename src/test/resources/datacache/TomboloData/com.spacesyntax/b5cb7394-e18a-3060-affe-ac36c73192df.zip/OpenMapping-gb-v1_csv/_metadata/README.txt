README

Name: Space Syntax OpenMapping
Formats: GeoJSON, GeoPackage, Shapefile, CSV, MIF
Data Type: vector lines with text and numeric attributes
Geometric Projection: EPSG/SRID: 27700 (OSGB 1936 / British National Grid)
Version: gb-v1
Published by: Space Syntax Limited
License: CC BY-SA 4.0  http://creativecommons.org/licenses/by-sa/4.0/">

For a full description of the data, and any enquiries visit: https://github.com/spacesyntax/OpenMapping

This package contains the following data:

Metadata:
+ README.txt - This file outlining information on the data package.
+ ssx_openmaps_gb_v1_schema.json - Machine readable table schema
+ ssx_openmaps_gb_v1_column_headers.csv - Column headers in csv format
+ ssx_openmaps_gb_v1_sample.csv - 5 row sample in csv format

Data:
+ csv/geojson/gpkg/mif/shp - containing the model in your chosen format
+ qgis-styles - QML style files compatible with QGIS, each file is named after the corresponding attribute in the model
